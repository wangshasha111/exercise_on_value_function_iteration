function [consumption_2] = consumptionFunction2(a_2,labor_2)
consumption_2 = a_2 * labor_2;
end